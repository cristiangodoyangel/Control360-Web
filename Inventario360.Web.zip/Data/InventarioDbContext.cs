﻿using System.Data.Entity;
using Inventario360.Web.Models;

namespace Inventario360.Web.Data
{
    public class InventarioDbContext : DbContext
    {
        public InventarioDbContext() : base("DefaultConnection")
        {
            // Estas configuraciones son opcionales pero seguras
            this.Configuration.ProxyCreationEnabled = false;
            this.Configuration.LazyLoadingEnabled = false;
        }

        public DbSet<Producto> Producto { get; set; }
        public DbSet<Proveedor> Proveedor { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Producto>().HasKey(p => p.ITEM);
            base.OnModelCreating(modelBuilder);
        }
    }
}
